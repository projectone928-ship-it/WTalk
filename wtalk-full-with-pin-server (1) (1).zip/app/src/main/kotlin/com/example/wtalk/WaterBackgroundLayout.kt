package com.example.wtalk

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.FrameLayout
import kotlin.math.sin

class WaterBackgroundLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.argb(55, 75, 221, 177)
    }
    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400L
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { phase += 0.018f; invalidate() }
    }

    init { setWillNotDraw(false); setLayerType(LAYER_TYPE_SOFTWARE, null) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!animator.isStarted) animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        fillPaint.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.rgb(1, 7, 13), Color.rgb(2, 20, 25), Color.rgb(1, 8, 14)),
            null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, fillPaint)
        fillPaint.shader = null

        val cx = w * 0.5f + sin(phase).toFloat() * 24f
        val cy = h * 0.38f
        fillPaint.shader = RadialGradient(cx, cy, w * 0.68f,
            Color.argb(28, 34, 184, 145), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, w * 0.68f, fillPaint)
        fillPaint.shader = null

        // Large, low-contrast fingerprint ridge field behind the UI.
        linePaint.color = Color.argb(42, 73, 210, 170)
        for (index in 0..8) {
            val inset = index * w * 0.055f
            val left = -w * 0.18f + inset
            val top = h * 0.22f + inset * 0.35f
            val right = w * 1.18f - inset
            val bottom = h * 0.78f - inset * 0.35f
            canvas.drawOval(left, top, right, bottom, linePaint)
        }

        // Slow biometric scan sweep.
        linePaint.color = Color.argb(38, 111, 255, 203)
        val scanY = (phase * h * 0.55f) % (h * 0.65f) + h * 0.16f
        canvas.drawLine(w * 0.08f, scanY, w * 0.92f, scanY, linePaint)

        val path = Path()
        linePaint.color = Color.argb(32, 89, 231, 191)
        for (row in 0..2) {
            path.reset()
            val yBase = h * (0.18f + row * 0.32f)
            for (x in 0..width step 22) {
                val y = yBase + sin(x * 0.012f + phase * (1f + row * 0.2f)).toFloat() * 5f
                if (x == 0) path.moveTo(x.toFloat(), y) else path.lineTo(x.toFloat(), y)
            }
            canvas.drawPath(path, linePaint)
        }
    }
}
