package com.example.wtalk

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class UserAdapter(private var users: MutableList<User>, private val onComeBack: (User) -> Unit) : RecyclerView.Adapter<UserAdapter.Holder>() {
    fun updateUserList(next: List<User>) { users.clear(); users.addAll(next); notifyDataSetChanged() }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false))
    override fun getItemCount() = users.size
    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(users[position])
    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val name: TextView = view.findViewById(R.id.userName)
        private val state: TextView = view.findViewById(R.id.userState)
        private val comeBack: Button = view.findViewById(R.id.btnComeBack)
        fun bind(user: User) { name.text = user.username; state.text = when { user.isSpeaking -> "Speaking"; user.isOnline -> "Online"; else -> "Offline" }; state.setTextColor(Color.parseColor(if (user.isSpeaking) "#EF4444" else if (user.isOnline) "#10B981" else "#94A3B8")); comeBack.visibility = if (user.isOnline) View.GONE else View.VISIBLE; comeBack.setOnClickListener { onComeBack(user) } }
    }
}
