package com.example.wtalk

data class User(val username: String, val isOnline: Boolean, val isSpeaking: Boolean)
