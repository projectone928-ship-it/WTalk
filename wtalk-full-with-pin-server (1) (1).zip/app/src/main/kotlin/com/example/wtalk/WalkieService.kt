package com.example.wtalk

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.animation.ValueAnimator
import android.content.Intent
import android.Manifest
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.content.pm.PackageManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.SeekBar
import android.widget.LinearLayout
import android.animation.ObjectAnimator
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import android.util.Base64
import java.util.concurrent.Executors
import java.net.URISyntaxException
import kotlin.math.abs
import kotlin.math.roundToInt

class WalkieService : Service() {

    companion object {
        const val ACTION_SHOW_FLOATING = "com.wtalk.SHOW_FLOATING"
        const val ACTION_HIDE_FLOATING = "com.wtalk.HIDE_FLOATING"
        const val ACTION_FLOATING_REMOVED = "com.wtalk.FLOATING_REMOVED"
        const val ACTION_CLOSE_APP = "com.wtalk.CLOSE_APP"
        const val ACTION_UPDATE_BADGE = "com.wtalk.UPDATE_BADGE"
        const val ACTION_APP_VISIBILITY = "com.wtalk.APP_VISIBILITY"
        private const val CHANNEL_ID = "wtalk_voice"
        private const val MESSAGE_CHANNEL_ID = "wtalk_messages"
        private const val NOTIFICATION_ID = 101
        private const val MESSAGE_NOTIFICATION_ID = 202
    }

    private var overlay: View? = null
    private var badge: TextView? = null
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private var bubbleSize = 0
    private var trashZone: View? = null
    private var trashZoneSize = 0
    private var snapAnimator: ValueAnimator? = null
    private var unreadCount = 0
    private var socket: Socket? = null
    private var serviceUsername = ""
    private var serviceChannel = ""
    private var servicePassword = ""
    private var appVisible = false
    private var notificationOnlyMode = false
    private var notificationModeRegistered = false
    private var floatingModeActive = false
    @Volatile private var isRecording = false
    private var talkRequested = false
    private var talkStarted = false
    private var audioRecord: AudioRecord? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var automaticGainControl: AutomaticGainControl? = null
    private val recordingExecutor = Executors.newSingleThreadExecutor()
    private val pttHandler = Handler(Looper.getMainLooper())
    private var bubbleView: ImageView? = null
    private var audioTrack: AudioTrack? = null
    private var selectedCommunicationDevice: android.media.AudioDeviceInfo? = null
    private var playbackExecutor = Executors.newSingleThreadExecutor()
    private var lastBackgroundNoticeAt = 0L
    private var volumePanel: View? = null
    private var talkPulseAnimator: ObjectAnimator? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val dimFloatingRunnable = Runnable {
        if (floatingModeActive && !talkRequested) {
            bubbleView?.animate()?.alpha(0.52f)?.setDuration(420L)?.start()
        }
    }

    override fun onCreate() {
        super.onCreate()
        val prefs = getSharedPreferences("WTalkPrefs", MODE_PRIVATE)
        serviceChannel = prefs.getString("CHANNEL", "") ?: ""
        servicePassword = prefs.getString("PASSWORD", "") ?: ""
        serviceUsername = prefs.getString("USERNAME", "") ?: ""
        notificationOnlyMode = prefs.getBoolean("NOTIFICATION_ONLY", false)
        configureAudioRoute()
        createChannel()
        createMessageChannel()
        val foregroundType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification(), foregroundType)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            serviceChannel = it.getStringExtra("CHANNEL") ?: serviceChannel
            servicePassword = it.getStringExtra("PASSWORD") ?: servicePassword
            serviceUsername = it.getStringExtra("USERNAME") ?: serviceUsername
            if (it.action == null) notificationOnlyMode = false
        }
        getSharedPreferences("WTalkPrefs", MODE_PRIVATE).edit()
            .putString("CHANNEL", serviceChannel)
            .putString("PASSWORD", servicePassword)
            .putString("USERNAME", serviceUsername)
            .putBoolean("NOTIFICATION_ONLY", notificationOnlyMode)
            .apply()
        if (serviceChannel.isNotEmpty() && serviceUsername.isNotEmpty()) connectSocketIfNeeded()
        when (intent?.action) {
            ACTION_SHOW_FLOATING -> showFloating()
            ACTION_HIDE_FLOATING -> {
                removeFloating()
                switchToNotificationOnly()
            }
            ACTION_APP_VISIBILITY -> {
                appVisible = intent.getBooleanExtra("VISIBLE", false)
                if (!appVisible) switchToNotificationOnly()
            }
            ACTION_UPDATE_BADGE -> {
                if (intent.getBooleanExtra("INCREMENT_UNREAD", false)) {
                    unreadCount = (unreadCount + 1).coerceAtMost(999)
                } else {
                    unreadCount = intent.getIntExtra("UNREAD_COUNT", 0).coerceAtLeast(0)
                }
                updateBadge()
            }
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (floatingModeActive) {
            super.onTaskRemoved(rootIntent)
            return
        }
        appVisible = false
        switchToNotificationOnly()
        super.onTaskRemoved(rootIntent)
    }

    private fun switchToNotificationOnly() {
        if (notificationOnlyMode && notificationModeRegistered) return
        notificationOnlyMode = true
        getSharedPreferences("WTalkPrefs", MODE_PRIVATE).edit()
            .putBoolean("NOTIFICATION_ONLY", true)
            .apply()
        stopTalk()
        runCatching { audioTrack?.pause() }
        safeEmit("leave_channel", JSONObject().apply {
            put("username", serviceUsername)
            put("channelName", serviceChannel)
        })
        notificationModeRegistered = safeEmit("register_notification", JSONObject().apply {
            put("username", serviceUsername)
            put("channelName", serviceChannel)
            put("password", servicePassword)
        })
    }

    private fun safeEmit(event: String, data: JSONObject): Boolean {
        val currentSocket = socket ?: return false
        if (!currentSocket.connected()) return false
        return runCatching {
            currentSocket.emit(event, data)
            true
        }.getOrDefault(false)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "WTalk voice", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun createMessageChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(MESSAGE_CHANNEL_ID, "WTalk messages", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun configureAudioRoute() {
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        runCatching {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            val preferredTypes = setOf(
                android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                android.media.AudioDeviceInfo.TYPE_BLE_HEADSET,
                android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET,
                android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                android.media.AudioDeviceInfo.TYPE_USB_HEADSET
            )
            selectedCommunicationDevice = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                audioManager.availableCommunicationDevices.firstOrNull { it.type in preferredTypes }
            } else {
                @Suppress("DEPRECATION")
                audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.type in preferredTypes }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val outputDevice = selectedCommunicationDevice ?: audioManager.availableCommunicationDevices.firstOrNull {
                    it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                }
                outputDevice?.let { audioManager.setCommunicationDevice(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.isSpeakerphoneOn = selectedCommunicationDevice == null
                if (selectedCommunicationDevice?.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                    @Suppress("DEPRECATION")
                    audioManager.startBluetoothSco()
                    @Suppress("DEPRECATION")
                    audioManager.isBluetoothScoOn = true
                }
            }
        }
    }

    private fun notification(): Notification = Notification.Builder(this, CHANNEL_ID)
        .setContentTitle("WTalk is ready")
        .setContentText("Push-to-talk channel is active")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .build()

    private fun connectSocketIfNeeded() {
        if (socket?.connected() == true || socket != null) return
        try {
            socket = IO.socket("https://wtalk-n120.onrender.com", IO.Options().apply {
                forceNew = true
                reconnection = true
                reconnectionAttempts = Int.MAX_VALUE
                reconnectionDelay = 2000
            }).apply {
                on(Socket.EVENT_CONNECT) {
                    val event = if (notificationOnlyMode) "register_notification" else "join_channel"
                    emit(event, JSONObject().apply {
                        put("channelName", serviceChannel)
                        put("password", servicePassword)
                        put("username", serviceUsername)
                    })
                    notificationModeRegistered = notificationOnlyMode
                }
                on(Socket.EVENT_DISCONNECT) {
                    notificationModeRegistered = false
                }
                on("talk_granted") {
                    if (talkRequested) {
                        talkStarted = true
                        startRecording()
                    }
                }
                on("talk_denied") {
                    talkRequested = false
                    talkStarted = false
                }
                on("offline_notification") { args ->
                    if (args.isNotEmpty() && args[0] is JSONObject) {
                        val data = args[0] as JSONObject
                        unreadCount = (unreadCount + 1).coerceAtMost(999)
                        updateBadge()
                        showOfflineNotification(
                            data.optString("title", "WTalk"),
                            data.optString("message", "You have a new notification")
                        )
                    }
                }
                on("offline_notifications") { args ->
                    if (args.isNotEmpty() && args[0] is JSONObject) {
                        val data = args[0] as JSONObject
                        val count = data.optInt("count", 0)
                        if (count > 0) {
                            unreadCount = (unreadCount + count).coerceAtMost(999)
                            updateBadge()
                            showOfflineNotification("WTalk", "$count notification(s) waiting for you")
                        }
                    }
                }
                on("floor_status") { args ->
                    runCatching {
                        if (!appVisible && args.isNotEmpty() && args[0] is JSONObject) {
                            val data = args[0] as JSONObject
                            val speaker = data.optString("speaker", "Another user")
                            val now = System.currentTimeMillis()
                            if (data.optBoolean("isBusy", false) && speaker != serviceUsername &&
                                now - lastBackgroundNoticeAt > 5000L) {
                                lastBackgroundNoticeAt = now
                                unreadCount = (unreadCount + 1).coerceAtMost(999)
                                updateBadge()
                                showMessageNotification(speaker)
                            }
                        }
                    }
                }
                on("receive_audio") { args ->
                    if (args.isNotEmpty() && args[0] is JSONObject) {
                        val data = args[0] as JSONObject
                        if (data.optString("username") != serviceUsername) {
                            playIncomingAudio(data.optString("audioData", data.optString("audio", "")))
                        }
                    }
                }
                connect()
            }
        } catch (e: URISyntaxException) {
            e.printStackTrace()
        }
    }

    private fun showMessageNotification(sender: String) {
        runCatching {
            val launchIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            )
            val notification = NotificationCompat.Builder(this, MESSAGE_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("WTalk message")
                .setContentText("$sender is speaking")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()
            getSystemService(NotificationManager::class.java).notify(MESSAGE_NOTIFICATION_ID, notification)
        }
    }

    private fun showOfflineNotification(title: String, message: String) {
        runCatching {
            val launchIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            val pendingIntent = PendingIntent.getActivity(this, 1, launchIntent, flags)
            val notification = NotificationCompat.Builder(this, MESSAGE_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()
            getSystemService(NotificationManager::class.java).notify(MESSAGE_NOTIFICATION_ID, notification)
        }
    }

    private fun requestTalk() {
        if (talkRequested || serviceChannel.isEmpty() || serviceUsername.isEmpty()) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (socket?.connected() != true) connectSocketIfNeeded()
        talkRequested = true
        socket?.emit("request_talk", JSONObject().apply {
            put("channelName", serviceChannel)
            put("username", serviceUsername)
        })
    }

    private fun stopTalk() {
        pttHandler.removeCallbacksAndMessages(null)
        talkPulseAnimator?.cancel()
        talkPulseAnimator = null
        bubbleView?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(140L)?.start()
        if (talkRequested) {
            socket?.emit("stop_talk", JSONObject().apply {
                put("channelName", serviceChannel)
                put("username", serviceUsername)
            })
        }
        talkRequested = false
        talkStarted = false
        isRecording = false
    }

    private fun startRecording() {
        if (isRecording || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        isRecording = true
        recordingExecutor.execute {
            val sampleRate = 16000
            val packetSize = 640 // 20 ms of mono 16-bit PCM at 16 kHz
            val minSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val bufferSize = if (minSize > 0) maxOf(minSize, packetSize * 2) else packetSize * 2
            try {
                // Re-assert voice-communication routing when a game has changed audio mode.
                configureAudioRoute()
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    selectedCommunicationDevice?.let { audioRecord?.setPreferredDevice(it) }
                }
                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    audioRecord?.release()
                    audioRecord = null
                    isRecording = false
                    return@execute
                }
                val sessionId = audioRecord?.audioSessionId ?: 0
                if (sessionId != 0) {
                    runCatching {
                        if (NoiseSuppressor.isAvailable()) {
                            noiseSuppressor = NoiseSuppressor.create(sessionId)
                            noiseSuppressor?.enabled = true
                        }
                    }
                    runCatching {
                        if (AcousticEchoCanceler.isAvailable()) {
                            echoCanceler = AcousticEchoCanceler.create(sessionId)
                            echoCanceler?.enabled = true
                        }
                    }
                }
                audioRecord?.startRecording()
                val buffer = ByteArray(packetSize)
                while (isRecording) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0 && socket?.connected() == true) {
                        socket?.emit("send_audio", JSONObject().apply {
                            put("channelName", serviceChannel)
                            put("username", serviceUsername)
                            put("audioData", Base64.encodeToString(buffer, 0, read, Base64.NO_WRAP))
                        })
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                runCatching { audioRecord?.stop() }
                runCatching { audioRecord?.release() }
                runCatching { noiseSuppressor?.release() }
                runCatching { echoCanceler?.release() }
                runCatching { automaticGainControl?.release() }
                noiseSuppressor = null
                echoCanceler = null
                automaticGainControl = null
                audioRecord = null
            }
        }
    }

    private fun playIncomingAudio(encodedAudio: String) {
        if (encodedAudio.isEmpty()) return
        playbackExecutor.execute {
            try {
                val bytes = Base64.decode(encodedAudio, Base64.DEFAULT)
                if (audioTrack == null) {
                    val minSize = AudioTrack.getMinBufferSize(16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                    val bufferSize = if (minSize > 0) maxOf(minSize, 2048) else 2048
                    audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        AudioTrack.Builder()
                            .setAudioAttributes(AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build())
                            .setAudioFormat(AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(16000)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                            .setBufferSizeInBytes(bufferSize)
                            .setTransferMode(AudioTrack.MODE_STREAM)
                            .build()
                    } else {
                        @Suppress("DEPRECATION")
                        AudioTrack(AudioManager.STREAM_MUSIC, 16000, AudioFormat.CHANNEL_OUT_MONO,
                            AudioFormat.ENCODING_PCM_16BIT, bufferSize, AudioTrack.MODE_STREAM)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        selectedCommunicationDevice?.let { audioTrack?.setPreferredDevice(it) }
                    }
                    audioTrack?.setVolume(
                        getSharedPreferences("WTalkPrefs", MODE_PRIVATE).getInt("APP_VOLUME", 100) / 100f
                    )
                    audioTrack?.play()
                }
                if (audioTrack?.playState != AudioTrack.PLAYSTATE_PLAYING) {
                    audioTrack?.play()
                }
                audioTrack?.write(bytes, 0, bytes.size)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun applyPcmGain(input: ByteArray, length: Int, gain: Float): ByteArray {
        val output = input.copyOf(length)
        var i = 0
        while (i + 1 < output.size) {
            val sample = (output[i].toInt() and 0xff) or ((output[i + 1].toInt() and 0xff) shl 8)
            val signed = if (sample and 0x8000 != 0) sample - 0x10000 else sample
            val boosted = (signed * gain).toInt().coerceIn(-32768, 32767)
            output[i] = (boosted and 0xff).toByte()
            output[i + 1] = ((boosted shr 8) and 0xff).toByte()
            i += 2
        }
        return output
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun showFloating() {
        if (overlay != null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return

        notificationOnlyMode = false
        notificationModeRegistered = false
        floatingModeActive = true
        getSharedPreferences("WTalkPrefs", MODE_PRIVATE).edit()
            .putBoolean("NOTIFICATION_ONLY", false)
            .apply()
        if (socket?.connected() == true) {
            socket?.emit("join_channel", JSONObject().apply {
                put("channelName", serviceChannel)
                put("password", servicePassword)
                put("username", serviceUsername)
            })
        } else {
            socket?.disconnect()
            socket = null
            connectSocketIfNeeded()
        }

        val density = resources.displayMetrics.density
        // Keep the overlay compact and close to the edge so it does not cover game controls.
        bubbleSize = (54 * density).roundToInt()
        val margin = (6 * density).roundToInt()
        val windowManager = getSystemService(WindowManager::class.java)

        val container = FrameLayout(this)
        container.clipChildren = false
        container.clipToPadding = false
        val bubble = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setColorFilter(Color.rgb(226, 255, 246))
            contentDescription = "WTalk floating talk button"
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.argb(185, 90, 235, 191),
                    Color.argb(140, 26, 122, 103),
                    Color.argb(180, 4, 34, 37)
                )
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke((1.5f * density).roundToInt(), Color.argb(220, 132, 255, 216))
            }
            elevation = 10f
            alpha = 0.88f
            val padding = (14 * density).roundToInt()
            setPadding(padding, padding, padding, padding)
        }
        bubbleView = bubble
        container.addView(bubble, FrameLayout.LayoutParams(bubbleSize, bubbleSize))

        badge = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(220, 45, 55))
                setStroke((1 * density).roundToInt(), Color.WHITE)
            }
            elevation = 14f
            visibility = View.GONE
        }
        val badgeSize = (23 * density).roundToInt()
        val badgeParams = FrameLayout.LayoutParams(badgeSize, badgeSize, Gravity.TOP or Gravity.END)
        badgeParams.setMargins(0, 0, (-3 * density).roundToInt(), 0)
        container.addView(badge, badgeParams)
        updateBadge()

        val params = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - bubbleSize - margin
            y = resources.displayMetrics.heightPixels / 3
        }

        val dragTouchListener = View.OnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    mainHandler.removeCallbacks(dimFloatingRunnable)
                    bubble.animate().alpha(1f).setDuration(120L).start()
                    snapAnimator?.cancel()
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    pttHandler.postDelayed({
                        if (!moved) {
                            requestTalk()
                            bubble.animate().scaleX(1.08f).scaleY(1.08f).setDuration(120L).start()
                            talkPulseAnimator = ObjectAnimator.ofFloat(bubble, View.ALPHA, 1f, 0.62f).apply {
                                duration = 520L
                                repeatCount = ObjectAnimator.INFINITE
                                repeatMode = ObjectAnimator.REVERSE
                                start()
                            }
                        }
                    }, 180L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (abs(dx) > 8 || abs(dy) > 8) {
                        pttHandler.removeCallbacksAndMessages(null)
                        if (!moved) showTrashZone()
                        moved = true
                    }
                    params.x = (startX + dx).roundToInt()
                    params.y = (startY + dy).roundToInt()
                    runCatching { windowManager.updateViewLayout(container, params) }
                    updateTrashZoneState(event.rawX, event.rawY)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    pttHandler.removeCallbacksAndMessages(null)
                    val wasTalking = talkRequested
                    stopTalk()
                    bubble.animate().scaleX(1f).scaleY(1f).setDuration(140L).start()
                    if (!moved) {
                        hideTrashZone()
                        unreadCount = 0
                        updateBadge()
                        if (!wasTalking) {
                            toggleVolumePanel(params)
                        }
                    } else if (isOverTrashZone(event.rawX, event.rawY)) {
                        closeApp()
                    } else {
                        snapToNearestEdge(params)
                        hideTrashZone()
                    }
                    mainHandler.removeCallbacks(dimFloatingRunnable)
                    mainHandler.postDelayed(dimFloatingRunnable, 2600L)
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    stopTalk()
                    bubble.animate().scaleX(1f).scaleY(1f).setDuration(140L).start()
                    hideTrashZone()
                    mainHandler.removeCallbacks(dimFloatingRunnable)
                    mainHandler.postDelayed(dimFloatingRunnable, 2600L)
                    true
                }
                else -> false
            }
        }
        bubble.setOnTouchListener(dragTouchListener)
        badge?.setOnTouchListener(dragTouchListener)

        overlay = container
        try {
            windowManager.addView(container, params)
            mainHandler.removeCallbacks(dimFloatingRunnable)
            mainHandler.postDelayed(dimFloatingRunnable, 2600L)
        } catch (e: Exception) {
            overlay = null
            badge = null
            bubbleView = null
            e.printStackTrace()
        }
    }

    private fun updateBadge() {
        mainHandler.post {
            val badgeView = badge ?: return@post
            runCatching {
                if (unreadCount <= 0) {
                    badgeView.visibility = View.GONE
                } else {
                    badgeView.text = if (unreadCount > 99) "99+" else unreadCount.toString()
                    badgeView.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun toggleVolumePanel(params: WindowManager.LayoutParams) {
        val existingPanel = volumePanel
        if (existingPanel != null) {
            runCatching { getSystemService(WindowManager::class.java).removeView(existingPanel) }
            volumePanel = null
            return
        }
        val density = resources.displayMetrics.density
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8 * density).roundToInt(), 0, (8 * density).roundToInt(), 0)
            background = GradientDrawable().apply {
                cornerRadius = 24 * density
                setColor(Color.argb(235, 20, 35, 58))
                setStroke((1 * density).roundToInt(), Color.argb(220, 130, 180, 255))
            }
            elevation = 16f
        }
        val slider = SeekBar(this).apply {
            max = 100
            progress = getSharedPreferences("WTalkPrefs", MODE_PRIVATE).getInt("APP_VOLUME", 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    audioTrack?.setVolume(progress / 100f)
                    getSharedPreferences("WTalkPrefs", MODE_PRIVATE).edit().putInt("APP_VOLUME", progress).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        panel.addView(slider, LinearLayout.LayoutParams((132 * density).roundToInt(), (48 * density).roundToInt()))
        val panelParams = WindowManager.LayoutParams(
            (148 * density).roundToInt(), (52 * density).roundToInt(), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (params.x - 150 * density).roundToInt().coerceAtLeast(4)
            y = params.y + (bubbleSize - height) / 2
        }
        volumePanel = panel
        runCatching { getSystemService(WindowManager::class.java).addView(panel, panelParams) }
    }

    private fun showTrashZone() {
        if (trashZone != null) return
        val density = resources.displayMetrics.density
        trashZoneSize = (76 * density).roundToInt()
        val trash = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_delete)
            setColorFilter(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(185, 55, 55, 65))
                setStroke((2 * density).roundToInt(), Color.WHITE)
            }
            alpha = 0.9f
            val padding = (20 * density).roundToInt()
            setPadding(padding, padding, padding, padding)
        }
        val params = WindowManager.LayoutParams(
            trashZoneSize, trashZoneSize, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = (24 * density).roundToInt()
        }
        trashZone = trash
        runCatching { getSystemService(WindowManager::class.java).addView(trash, params) }
    }

    private fun updateTrashZoneState(rawX: Float, rawY: Float) {
        val over = isOverTrashZone(rawX, rawY)
        trashZone?.alpha = if (over) 1f else 0.72f
        trashZone?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (over) Color.rgb(210, 45, 55) else Color.argb(185, 55, 55, 65))
            setStroke((2 * resources.displayMetrics.density).roundToInt(), Color.WHITE)
        }
    }

    private fun isOverTrashZone(rawX: Float, rawY: Float): Boolean {
        val height = resources.displayMetrics.heightPixels
        val zoneTop = height - trashZoneSize * 2
        return rawY >= zoneTop && rawX >= (resources.displayMetrics.widthPixels - trashZoneSize) / 2f &&
            rawX <= (resources.displayMetrics.widthPixels + trashZoneSize) / 2f
    }

    private fun hideTrashZone() {
        trashZone?.let { runCatching { getSystemService(WindowManager::class.java).removeView(it) } }
        trashZone = null
    }

    private fun snapToNearestEdge(params: WindowManager.LayoutParams) {
        val width = resources.displayMetrics.widthPixels
        val margin = (8 * resources.displayMetrics.density).roundToInt()
        val targetX = if (params.x + bubbleSize / 2 < width / 2) {
            margin
        } else {
            width - bubbleSize - margin
        }
        val start = params.x
        snapAnimator = ValueAnimator.ofInt(start, targetX).apply {
            duration = 220L
            addUpdateListener { animator ->
                params.x = animator.animatedValue as Int
                overlay?.let { view ->
                    runCatching { getSystemService(WindowManager::class.java).updateViewLayout(view, params) }
                }
            }
            start()
        }
    }

    private fun closeApp() {
        removeFloating()
        // Deleting the bubble must not stop the notification connection.
        // Keep this service alive in notification-only mode so incoming users
        // can still reach the device after the overlay has been removed.
        switchToNotificationOnly()
        startActivity(Intent(this, MainActivity::class.java).apply {
            action = ACTION_CLOSE_APP
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        })
    }

    private fun removeFloating() {
        snapAnimator?.cancel()
        floatingModeActive = false
        hideTrashZone()
        volumePanel?.let { runCatching { getSystemService(WindowManager::class.java).removeView(it) } }
        volumePanel = null
        overlay?.let { runCatching { getSystemService(WindowManager::class.java).removeView(it) } }
        overlay = null
        badge = null
        sendBroadcast(Intent(ACTION_FLOATING_REMOVED).setPackage(packageName))
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(dimFloatingRunnable)
        stopTalk()
        recordingExecutor.shutdownNow()
        playbackExecutor.shutdownNow()
        runCatching { audioTrack?.stop() }
        runCatching { audioTrack?.release() }
        audioTrack = null
        runCatching { noiseSuppressor?.release() }
        runCatching { echoCanceler?.release() }
        runCatching { automaticGainControl?.release() }
        socket?.off()
        socket?.disconnect()
        socket = null
        removeFloating()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
