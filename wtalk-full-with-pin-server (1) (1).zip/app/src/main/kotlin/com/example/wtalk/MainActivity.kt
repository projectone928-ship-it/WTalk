package com.example.wtalk

import android.Manifest
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.util.Base64
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.ImageView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONArray
import org.json.JSONObject
import java.net.URISyntaxException
import java.util.concurrent.Executors
import com.example.wtalk.R

class MainActivity : AppCompatActivity() {

    private lateinit var mSocket: Socket
    private var isAppVisible = false
    private var floatingModeRequested = false
    private var activePulseAnimator: ValueAnimator? = null
    private var isSpeakerAnimationActive = false
    @Volatile private var isRecording = false
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var selectedCommunicationDevice: AudioDeviceInfo? = null

    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var automaticGainControl: AutomaticGainControl? = null

    private val recordingExecutor = Executors.newSingleThreadExecutor()
    private val audioPlayerExecutor = Executors.newSingleThreadExecutor()

    private var channelName: String = ""
    private var channelPassword: String = ""
    private var username: String = ""

    private val sampleRate = 16000 
    private val channelConfigIn = AudioFormat.CHANNEL_IN_MONO
    private val channelConfigOut = AudioFormat.CHANNEL_OUT_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    
    private val bufferSizeIn by lazy {
        val size = AudioRecord.getMinBufferSize(sampleRate, channelConfigIn, audioFormat)
        if (size > 0) maxOf(size, 1280) else 1280
    }
    private val bufferSizeOut by lazy {
        val size = AudioTrack.getMinBufferSize(sampleRate, channelConfigOut, audioFormat)
        if (size > 0) maxOf(size, 2048) else 2048
    }

    private lateinit var btnTalk: FingerprintTalkButton
    private lateinit var tvServerStatus: TextView
    private lateinit var audioWaveView: AudioWaveView
    private lateinit var imgMic: ImageView
    private lateinit var tvInstruction: TextView
    private lateinit var btnFloatingLogo: ImageButton
    private lateinit var btnVolumeLogo: ImageButton
    private lateinit var drawerHandle: View
    private lateinit var drawerOverlay: View
    private lateinit var drawerPanel: View
    private var drawerTouchDownX = 0f
    private var drawerTouchDownY = 0f
    private var drawerIsOpen = false

    @Volatile private var appVoiceVolume: Float = 1.0f
    private lateinit var seekBarVolume: SeekBar
    private lateinit var tvVolumePercent: TextView

    private var switchFloatingButton: Switch? = null

    private lateinit var tvActiveSpeaker: TextView
    private lateinit var layoutActiveSpeaker: LinearLayout
    private lateinit var tvOnlineCount: TextView
    private lateinit var rvOnlineUsers: RecyclerView
    private lateinit var userAdapter: UserAdapter
    private val onlineUsersList = mutableListOf<User>()

    private var isReceiverRegistered = false

    // 1. Request permissions before starting the service
    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false

        if (audioGranted) {
            checkOverlayPermission()
            checkAndPromptBackgroundUsage()
        } else {
            Toast.makeText(this, "Microphone permission is required!", Toast.LENGTH_SHORT).show()
        }
    }

    private lateinit var sharedPreferences: SharedPreferences
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { prefs, key ->
        if (key == "APP_VOLUME") {
            val progress = prefs.getInt("APP_VOLUME", 100)
            appVoiceVolume = progress / 100.0f
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                audioTrack?.setVolume(appVoiceVolume)
            }

            runOnUiThread {
                if (::seekBarVolume.isInitialized && seekBarVolume.progress != progress) {
                    seekBarVolume.progress = progress
                    tvVolumePercent.text = "$progress%"
                }
            }
        }
    }

    private val floatingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == WalkieService.ACTION_FLOATING_REMOVED) {
                runOnUiThread {
                    switchFloatingButton?.isChecked = false
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent?.action == WalkieService.ACTION_CLOSE_APP) {
            finishAndRemoveTask()
            return
        }
        setContentView(R.layout.activity_main)
        stopService(Intent(this, WalkieService::class.java))
        setupEdgeToEdgeInsets()

        sharedPreferences = getSharedPreferences("WTalkPrefs", Context.MODE_PRIVATE)
        sharedPreferences.registerOnSharedPreferenceChangeListener(prefListener)

        tvServerStatus = findViewById(R.id.tvServerStatus)
        btnTalk = findViewById(R.id.btnTalk)
        audioWaveView = findViewById(R.id.audioWaveView)
        imgMic = findViewById(R.id.imgMic)
        tvInstruction = findViewById(R.id.tvInstruction)
        btnFloatingLogo = findViewById(R.id.btnFloatingLogo)
        btnVolumeLogo = findViewById(R.id.btnVolumeLogo)
        setupCompactControlListeners()
        drawerHandle = findViewById(R.id.drawerHandle)
        drawerOverlay = findViewById(R.id.drawerOverlay)
        drawerPanel = findViewById(R.id.drawerPanel)
        setupDrawerGesture()
        findViewById<View>(R.id.drawerChannelBox).setOnClickListener {
            showLoginDialog(sharedPreferences)
        }

        tvActiveSpeaker = findViewById(R.id.tvActiveSpeaker)
        layoutActiveSpeaker = findViewById(R.id.layoutActiveSpeaker)
        tvOnlineCount = findViewById(R.id.tvOnlineCount)
        rvOnlineUsers = findViewById(R.id.rvOnlineUsers)

        try {
            switchFloatingButton = findViewById(R.id.switchFloatingButton)
            setupFloatingSwitchListener()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Register Receiver Safely
        try {
            val filter = IntentFilter(WalkieService.ACTION_FLOATING_REMOVED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.registerReceiver(this, floatingReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(floatingReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            e.printStackTrace()
        }

        seekBarVolume = findViewById(R.id.seekBarVolume)
        tvVolumePercent = findViewById(R.id.tvVolumePercent)
        setupAppVoiceVolumeControl()

        setupRecyclerView()
        initAudioPlayer()
        setupUiAnimations()

        tvServerStatus.setOnClickListener {
            showLoginDialog(sharedPreferences)
        }

        // 2. Request required permissions before showing other prompts
        checkAndRequestPermissions()
        checkCredentialsAndConnect()

        btnTalk.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    btnTalk.setTalkPressed(true)
                    btnTalk.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90L).start()
                    if (::mSocket.isInitialized && mSocket.connected()) {
                        val reqData = JSONObject().apply {
                            put("channelName", channelName)
                            put("username", username)
                        }
                        mSocket.emit("request_talk", reqData)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    btnTalk.setTalkPressed(false)
                    btnTalk.animate().scaleX(1f).scaleY(1f).setDuration(140L)
                        .setInterpolator(OvershootInterpolator(1.4f)).start()
                    stopRecording()
                    
                    runOnUiThread {
                        btnTalk.text = "HOLD TO SPEAK"
                        audioWaveView.stopAnimation()
                        imgMic.visibility = View.VISIBLE
                        tvInstruction.text = "Hold to speak, release to listen"
                    }

                    if (::mSocket.isInitialized && mSocket.connected()) {
                        val stopData = JSONObject().apply {
                            put("channelName", channelName)
                            put("username", username)
                        }
                        mSocket.emit("stop_talk", stopData)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun setupEdgeToEdgeInsets() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.VANILLA_ICE_CREAM) return
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val content = findViewById<View>(android.R.id.content)
        ViewCompat.setOnApplyWindowInsetsListener(content) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(view.paddingLeft, bars.top, view.paddingRight, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(content)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == WalkieService.ACTION_CLOSE_APP) {
            finishAndRemoveTask()
        }
    }

    override fun onStart() {
        super.onStart()
        isAppVisible = true
    }

    override fun onStop() {
        isAppVisible = false
        if (!floatingModeRequested) sendServiceVisibility(false)
        super.onStop()
    }

    private fun sendServiceVisibility(visible: Boolean) {
        if (!visible && isFinishing) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val intent = Intent(this, WalkieService::class.java).apply {
            action = WalkieService.ACTION_APP_VISIBILITY
            putExtra("VISIBLE", visible)
            putExtra("CHANNEL", channelName)
            putExtra("PASSWORD", channelPassword)
            putExtra("USERNAME", username)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        }
    }

    private fun updateFloatingUnreadCount(count: Int) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val intent = Intent(this, WalkieService::class.java).apply {
            action = WalkieService.ACTION_UPDATE_BADGE
            putExtra("UNREAD_COUNT", count)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }
    }

    private fun addFloatingUnreadMessage() {
        if (isAppVisible) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val intent = Intent(this, WalkieService::class.java).apply {
            action = WalkieService.ACTION_UPDATE_BADGE
            putExtra("INCREMENT_UNREAD", true)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }
    }

    private fun setupUiAnimations() {
        val animatedViews = mutableListOf<View>(
            tvServerStatus,
            layoutActiveSpeaker,
            tvOnlineCount,
            rvOnlineUsers,
            btnFloatingLogo,
            btnVolumeLogo
        )
        switchFloatingButton?.let { animatedViews.add(it) }
        animatedViews.forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 22f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(index * 55L)
                .setDuration(420L)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
        btnTalk.alpha = 0f
        btnTalk.scaleX = 0.88f
        btnTalk.scaleY = 0.88f
        btnTalk.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(220L)
            .setDuration(520L)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()
    }

    private fun setupCompactControlListeners() {
        btnFloatingLogo.setOnClickListener {
            switchFloatingButton?.isChecked = !(switchFloatingButton?.isChecked ?: false)
            it.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80L)
                .withEndAction { it.animate().scaleX(1f).scaleY(1f).setDuration(180L).start() }
                .start()
        }
        btnVolumeLogo.setOnClickListener {
            showCompactVolumeDialog()
            it.animate().rotationBy(8f).setDuration(90L)
                .withEndAction { it.animate().rotation(0f).setDuration(160L).start() }
                .start()
        }
    }

    private fun setupDrawerGesture() {
        drawerOverlay.setOnClickListener { closeControlDrawer() }
        drawerPanel.setOnClickListener { /* Consume taps inside the drawer. */ }
        drawerHandle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    drawerTouchDownX = event.rawX
                    drawerTouchDownY = event.rawY
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val deltaX = event.rawX - drawerTouchDownX
                    val deltaY = event.rawY - drawerTouchDownY
                    if (!drawerIsOpen && deltaX < -48f && kotlin.math.abs(deltaX) > kotlin.math.abs(deltaY)) {
                        openControlDrawer()
                    } else if (drawerIsOpen && deltaX > 48f && kotlin.math.abs(deltaX) > kotlin.math.abs(deltaY)) {
                        closeControlDrawer()
                    } else if (!drawerIsOpen) {
                        openControlDrawer()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
    }

    private fun openControlDrawer() {
        if (drawerIsOpen) return
        drawerIsOpen = true
        drawerOverlay.visibility = View.VISIBLE
        drawerPanel.post {
            drawerPanel.translationX = drawerPanel.width.toFloat()
            drawerOverlay.alpha = 0f
            drawerOverlay.animate().alpha(1f).setDuration(180L).start()
            drawerPanel.animate()
                .translationX(0f)
                .setDuration(320L)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    private fun closeControlDrawer() {
        if (!drawerIsOpen) return
        drawerIsOpen = false
        drawerPanel.animate()
            .translationX(drawerPanel.width.toFloat())
            .setDuration(250L)
            .setInterpolator(DecelerateInterpolator(1.4f))
            .withEndAction {
                drawerOverlay.animate().alpha(0f).setDuration(120L).withEndAction {
                    drawerOverlay.visibility = View.GONE
                }.start()
            }
            .start()
    }

    private fun showCompactVolumeDialog() {
        val current = sharedPreferences.getInt("APP_VOLUME", 100)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 18, 44, 8)
        }
        val valueLabel = TextView(this).apply {
            text = "Voice volume: $current%"
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
        }
        val slider = SeekBar(this).apply {
            max = 100
            progress = current
        }
        content.addView(valueLabel)
        content.addView(slider)
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val safe = progress.coerceIn(0, 100)
                    appVoiceVolume = safe / 100.0f
                    audioTrack?.setVolume(appVoiceVolume)
                    sharedPreferences.edit().putInt("APP_VOLUME", safe).apply()
                    valueLabel.text = "Voice volume: $safe%"
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        AlertDialog.Builder(this)
            .setTitle("Volume")
            .setView(content)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun animateActiveSpeaker(active: Boolean) {
        if (active == isSpeakerAnimationActive && activePulseAnimator?.isRunning == true) return
        isSpeakerAnimationActive = active
        activePulseAnimator?.cancel()
        if (!active) {
            layoutActiveSpeaker.animate().scaleX(1f).scaleY(1f).setDuration(180L).start()
            tvActiveSpeaker.animate().alpha(1f).setDuration(180L).start()
            return
        }
        activePulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1050L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { animator ->
                val t = animator.animatedValue as Float
                val pulse = 1f + (0.010f * t)
                layoutActiveSpeaker.scaleX = pulse
                layoutActiveSpeaker.scaleY = pulse
                tvActiveSpeaker.alpha = 0.86f + (0.14f * t)
            }
            start()
        }
    }

    private fun setupFloatingSwitchListener() {
        switchFloatingButton?.isChecked = false

        switchFloatingButton?.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    checkOverlayPermission()
                    switchFloatingButton?.isChecked = false
                } else {
                    toggleFloatingButton(true)
                }
            } else {
                toggleFloatingButton(false)
            }
        }
    }

    private fun toggleFloatingButton(show: Boolean) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission is required.", Toast.LENGTH_SHORT).show()
            return
        }

        floatingModeRequested = show
        val serviceIntent = Intent(this, WalkieService::class.java).apply {
            action = if (show) WalkieService.ACTION_SHOW_FLOATING else WalkieService.ACTION_HIDE_FLOATING
            putExtra("CHANNEL", channelName)
            putExtra("PASSWORD", channelPassword)
            putExtra("USERNAME", username)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            if (show) {
                if (::mSocket.isInitialized) mSocket.disconnect()
                window.decorView.postDelayed({ finishAndRemoveTask() }, 250L)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // 3. Guard the service start with permission checks
    private fun startWalkieService() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        if (channelName.isNotEmpty() && username.isNotEmpty()) {
            val serviceIntent = Intent(this, WalkieService::class.java).apply {
                putExtra("CHANNEL", channelName)
                putExtra("PASSWORD", channelPassword)
                putExtra("USERNAME", username)
            }

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun checkAndPromptBackgroundUsage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                AlertDialog.Builder(this)
                    .setTitle("Background Access Needed")
                    .setMessage("Allow WTalk to run in the background so you can keep receiving channel audio and alerts.")
                    .setPositiveButton("Open Settings") { _, _ ->
                        try {
                            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                data = Uri.parse("package:$packageName")
                            }
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    .setNegativeButton("Not now", null)
                    .setCancelable(false)
                    .show()
            }
        }
    }

    // 4. Check and request permissions
    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionsLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            // Start immediately when permissions are already granted
            startWalkieService()
            checkOverlayPermission()
            checkAndPromptBackgroundUsage()
        }
    }

    private fun checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                AlertDialog.Builder(this)
                    .setTitle("Overlay Permission Needed")
                    .setMessage("Allow WTalk to display the floating push-to-talk bubble over other apps.")
                    .setPositiveButton("Open Settings") { _, _ ->
                        try {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    .setNegativeButton("Not now", null)
                    .setCancelable(false)
                    .show()
            }
        }
    }

    private fun setupAppVoiceVolumeControl() {
        val savedVol = sharedPreferences.getInt("APP_VOLUME", 100)
        appVoiceVolume = savedVol / 100.0f

        seekBarVolume.max = 100
        seekBarVolume.progress = savedVol
        tvVolumePercent.text = "$savedVol%"

        seekBarVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    appVoiceVolume = progress / 100.0f
                    tvVolumePercent.text = "$progress%"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        audioTrack?.setVolume(appVoiceVolume)
                    }
                    sharedPreferences.edit().putInt("APP_VOLUME", progress).apply()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupRecyclerView() {
        userAdapter = UserAdapter(onlineUsersList) { targetUser ->
            if (!targetUser.isOnline && ::mSocket.isInitialized && mSocket.connected()) {
                val comeBackData = JSONObject().apply {
                    put("channelName", channelName)
                    put("senderUsername", username)
                    put("targetUsername", targetUser.username)
                    put("title", "Come back to WTalk")
                    put("message", "$username is waiting for you in WTalk.")
                }
                mSocket.emit("notify_user", comeBackData)
                Toast.makeText(this, "Come Back notification queued for ${targetUser.username}.", Toast.LENGTH_SHORT).show()
            }
        }
        rvOnlineUsers.layoutManager = LinearLayoutManager(this)
        rvOnlineUsers.adapter = userAdapter
    }

    private fun checkCredentialsAndConnect() {
        val savedUsername = sharedPreferences.getString("USERNAME", null)
        val savedChannel = sharedPreferences.getString("CHANNEL", null)
        val savedPassword = sharedPreferences.getString("PASSWORD", null)

        if (savedUsername.isNullOrEmpty() || savedChannel.isNullOrEmpty() || savedPassword.isNullOrEmpty()) {
            showLoginDialog(sharedPreferences)
        } else {
            username = savedUsername
            channelName = savedChannel
            channelPassword = savedPassword
            connectToSocketServer()
        }
    }

    private fun showLoginDialog(sharedPref: SharedPreferences) {
        val lockedUsername = sharedPref.getString("USERNAME", "")?.trim().orEmpty()
        val usernameIsLocked = lockedUsername.isNotEmpty() || sharedPref.getBoolean("USERNAME_LOCKED", false)
        val layout = layoutInflater.inflate(R.layout.dialog_credentials, null)
        val etUsername = layout.findViewById<EditText>(R.id.etDialogUsername)
        val etChannel = layout.findViewById<EditText>(R.id.etDialogChannel)
        val etPassword = layout.findViewById<EditText>(R.id.etDialogPassword)

        etUsername.setText(if (usernameIsLocked) lockedUsername else username)
        etUsername.isEnabled = !usernameIsLocked
        etUsername.alpha = if (usernameIsLocked) 0.62f else 1f
        etChannel.setText(channelName)
        etPassword.setText(channelPassword)

        val dialog = AlertDialog.Builder(this)
            .setView(layout)
            .setCancelable(false)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("Connect") { _, _ ->
                val enteredName = if (usernameIsLocked) lockedUsername else etUsername.text.toString().trim()
                val enteredChannel = etChannel.text.toString().trim()
                val enteredPassword = etPassword.text.toString().trim()

                if (enteredName.isNotEmpty() && enteredChannel.isNotEmpty() && enteredPassword.isNotEmpty()) {
                    username = enteredName
                    channelName = enteredChannel
                    channelPassword = enteredPassword

                    sharedPref.edit().apply {
                        putString("USERNAME", username)
                        putBoolean("USERNAME_LOCKED", true)
                        putString("CHANNEL", channelName)
                        putString("PASSWORD", channelPassword)
                        apply()
                    }

                    if (::mSocket.isInitialized && mSocket.connected()) {
                        mSocket.disconnect()
                    }
                    connectToSocketServer()
                } else {
                    Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show()
                    showLoginDialog(sharedPref)
                }
            }
            .show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.rgb(82, 226, 185))
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.rgb(130, 205, 224))
    }

    private fun connectToSocketServer() {
        setConnectionStatus("CONNECTING")

        try {
            val opts = IO.Options().apply {
                forceNew = true
                reconnection = true
                reconnectionAttempts = Int.MAX_VALUE
                reconnectionDelay = 2000
            }
            mSocket = IO.socket("https://wtalk-n120.onrender.com", opts)

            mSocket.on(Socket.EVENT_CONNECT) {
                setConnectionStatus("CONNECTED")

                runOnUiThread {
                    btnTalk.text = "HOLD TO SPEAK"
                    tvInstruction.text = "Hold to speak, release to listen"
                }

                val joinData = JSONObject().apply {
                    put("channelName", channelName)
                    put("password", channelPassword)
                    put("username", username)
                }
                mSocket.emit("join_channel", joinData)
            }

            mSocket.on("join_result") { args ->
                if (args.isNotEmpty()) {
                    val res = args[0] as JSONObject
                    val success = res.optBoolean("success", false)
                    val message = res.optString("message", "")
                    
                    runOnUiThread {
                        if (!success) {
                            Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                            showLoginDialog(sharedPreferences)
                        } else {
                            Toast.makeText(this@MainActivity, "Joined $channelName", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            mSocket.on(Socket.EVENT_CONNECT_ERROR) { setConnectionStatus("FAILED") }
            mSocket.on(Socket.EVENT_DISCONNECT) { setConnectionStatus("FAILED") }

            val handleUserListUpdate = { args: Array<Any> ->
                if (args.isNotEmpty()) {
                    val updatedList = mutableListOf<User>()

                    try {
                        val usersArray = if (args[0] is JSONArray) {
                            args[0] as JSONArray
                        } else {
                            (args[0] as JSONObject).optJSONArray("users")
                        }

                        if (usersArray != null) {
                            for (i in 0 until usersArray.length()) {
                                val userObj = usersArray.getJSONObject(i)
                                updatedList.add(
                                    User(
                                        username = userObj.optString("username", "Unknown"),
                                        isOnline = userObj.optBoolean("isOnline", false),
                                        isSpeaking = userObj.optBoolean("isSpeaking", false)
                                    )
                                )
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    runOnUiThread {
                        val onlineCount = updatedList.count { it.isOnline }
                        tvOnlineCount.text = "Online Members ($onlineCount/${updatedList.size})"
                        userAdapter.updateUserList(updatedList)
                    }
                }
            }

            mSocket.on("update_user_list") { args -> handleUserListUpdate(args) }
            mSocket.on("users_list") { args -> handleUserListUpdate(args) }

            mSocket.on("floor_status") { args ->
                if (args.isNotEmpty()) {
                    val data = args[0] as JSONObject
                    val isBusy = data.optBoolean("isBusy", false)
                    val speaker = data.optString("speaker", "")

                    runOnUiThread {
                        if (isBusy) {
                            animateActiveSpeaker(true)
                            tvActiveSpeaker.text = "$speaker is speaking"
                            tvActiveSpeaker.setTextColor(Color.parseColor("#63E6FF"))

                            if (speaker != username) {
                                btnTalk.isEnabled = false
                                imgMic.visibility = View.GONE
                                audioWaveView.startAnimation()
                                btnTalk.text = "🟢 $speaker talking.."
                                tvInstruction.text = "Line is currently busy ($speaker speaking)"
                            }
                        } else {
                            animateActiveSpeaker(false)
                            tvActiveSpeaker.text = "No one is speaking"
                            tvActiveSpeaker.setTextColor(Color.parseColor("#10B981"))

                            btnTalk.isEnabled = true
                            audioWaveView.stopAnimation()
                            imgMic.visibility = View.VISIBLE
                            btnTalk.text = "HOLD TO SPEAK"
                            tvInstruction.text = "Hold to speak, release to listen"
                        }
                    }
                }
            }

            mSocket.on("talk_granted") {
                runOnUiThread {
                    imgMic.visibility = View.GONE
                    audioWaveView.startAnimation()
                    btnTalk.text = "SPEAKING..."
                    tvInstruction.text = "Release button to stop transmission"
                    startRecording()
                }
            }

            mSocket.on("talk_denied") { args ->
                runOnUiThread {
                    var msg = "Line is currently busy!"
                    if (args.isNotEmpty() && args[0] is JSONObject) {
                        msg = (args[0] as JSONObject).optString("message", msg)
                    }
                    Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                }
            }

            mSocket.on("receive_audio") { args ->
                if (args.isNotEmpty() && !isRecording) {
                    audioPlayerExecutor.execute {
                        try {
                            val dataObj = args[0] as JSONObject
                            val sender = dataObj.optString("username", "")

                            if (sender != username) {
                                val base64Audio = dataObj.optString("audioData", dataObj.optString("audio", ""))

                                if (base64Audio.isNotEmpty()) {
                                    val audioBytes = Base64.decode(base64Audio, Base64.DEFAULT)
                                    if (audioTrack?.playState != AudioTrack.PLAYSTATE_PLAYING) {
                                        audioTrack?.play()
                                    }
                                    val currentVol = sharedPreferences.getInt("APP_VOLUME", 100) / 100.0f
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                        audioTrack?.setVolume(currentVol)
                                    }
                                    val written = audioTrack?.write(audioBytes, 0, audioBytes.size) ?: -1
                                    if (written < 0) {
                                        runCatching { audioTrack?.stop() }
                                        runCatching { audioTrack?.release() }
                                        audioTrack = null
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }

            mSocket.connect()
        } catch (e: URISyntaxException) {
            e.printStackTrace()
            setConnectionStatus("FAILED")
        }
    }

    private fun initAudioPlayer() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        selectedCommunicationDevice = selectCommunicationDevice(audioManager)

        val savedVol = sharedPreferences.getInt("APP_VOLUME", 100)
        appVoiceVolume = savedVol / 100.0f

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(audioFormat)
                            .setSampleRate(sampleRate)
                            .setChannelMask(channelConfigOut)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSizeOut)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                audioTrack = AudioTrack(
                    AudioManager.STREAM_VOICE_CALL,
                    sampleRate,
                    channelConfigOut,
                    audioFormat,
                    bufferSizeOut,
                    AudioTrack.MODE_STREAM
                )
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                selectedCommunicationDevice?.let { audioTrack?.setPreferredDevice(it) }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                audioTrack?.setVolume(appVoiceVolume)
            }
            audioTrack?.play()
        } catch (e: Exception) {
            e.printStackTrace()
            audioTrack?.release()
            audioTrack = null
        }
    }

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return

        if (isRecording) return
        isRecording = true

        recordingExecutor.execute {
            try {
                val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                selectedCommunicationDevice = selectCommunicationDevice(audioManager)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    selectedCommunicationDevice?.let { audioTrack?.setPreferredDevice(it) }
                }
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    sampleRate,
                    channelConfigIn,
                    audioFormat,
                    bufferSizeIn
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    selectedCommunicationDevice?.let { audioRecord?.setPreferredDevice(it) }
                }
                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    audioRecord?.release()
                    audioRecord = null
                    isRecording = false
                    return@execute
                }

                val audioSessionId = audioRecord?.audioSessionId ?: 0
                if (audioSessionId != 0) {
                    if (NoiseSuppressor.isAvailable()) {
                        try {
                            noiseSuppressor = NoiseSuppressor.create(audioSessionId)
                            noiseSuppressor?.enabled = true
                        } catch (e: Exception) { e.printStackTrace() }
                    }
                    if (AcousticEchoCanceler.isAvailable()) {
                        try {
                            echoCanceler = AcousticEchoCanceler.create(audioSessionId)
                            echoCanceler?.enabled = true
                        } catch (e: Exception) { e.printStackTrace() }
                    }
                    if (AutomaticGainControl.isAvailable()) {
                        runCatching {
                            automaticGainControl = AutomaticGainControl.create(audioSessionId)
                            automaticGainControl?.enabled = true
                        }
                    }
                }

                audioRecord?.startRecording()

                val packetSize = 640 // 20 ms of mono 16-bit PCM at 16 kHz
                val buffer = ByteArray(packetSize)

                while (isRecording) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        val rawData = buffer.copyOf(read)
                        val base64Audio = Base64.encodeToString(rawData, Base64.NO_WRAP)
                        
                        val audioObj = JSONObject().apply {
                            put("channelName", channelName)
                            put("username", username)
                            put("audioData", base64Audio)
                        }
                        if (::mSocket.isInitialized && mSocket.connected()) {
                            mSocket.emit("send_audio", audioObj)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                runCatching { noiseSuppressor?.release() }
                runCatching { echoCanceler?.release() }
                runCatching { automaticGainControl?.release() }
                runCatching { audioRecord?.stop() }
                runCatching { audioRecord?.release() }
                noiseSuppressor = null
                echoCanceler = null
                automaticGainControl = null
                audioRecord = null
            }
        }
    }

    private fun selectCommunicationDevice(audioManager: AudioManager): AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val preferredTypes = setOf(
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_BLE_HEADSET,
            AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_USB_HEADSET
        )
        val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            audioManager.availableCommunicationDevices.firstOrNull { it.type in preferredTypes }
        } else {
            @Suppress("DEPRECATION")
            audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.type in preferredTypes }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val outputDevice = device ?: audioManager.availableCommunicationDevices.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
            }
            if (outputDevice != null) audioManager.setCommunicationDevice(outputDevice)
        } else {
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = device == null
            if (device?.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                @Suppress("DEPRECATION")
                audioManager.startBluetoothSco()
                @Suppress("DEPRECATION")
                audioManager.isBluetoothScoOn = true
            }
        }
        return device
    }

    private fun stopRecording() {
        isRecording = false
    }

    override fun onDestroy() {
        activePulseAnimator?.cancel()
        super.onDestroy()
        
        if (isReceiverRegistered) {
            try {
                unregisterReceiver(floatingReceiver)
                isReceiverRegistered = false
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        try {
            sharedPreferences.unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        isRecording = false
        if (::mSocket.isInitialized) {
            mSocket.disconnect()
        }
        recordingExecutor.shutdown()
        audioPlayerExecutor.shutdown()
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setConnectionStatus(status: String) {
        runOnUiThread {
            when (status) {
                "CONNECTING" -> {
                    tvServerStatus.text = "Connecting..."
                    tvServerStatus.setTextColor(Color.parseColor("#FBBF24"))
                }
                "CONNECTED" -> {
                    tvServerStatus.text = "Channel: $channelName (Connected)"
                    tvServerStatus.setTextColor(Color.parseColor("#34D399"))
                }
                "FAILED" -> {
                    tvServerStatus.text = "Failed to connect"
                    tvServerStatus.setTextColor(Color.parseColor("#EF4444"))
                }
            }
        }
    }
}
