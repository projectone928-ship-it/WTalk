package com.example.wtalk

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.LinearLayout
import kotlin.math.sin

class LiquidSurfaceLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ridgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.1f
        color = Color.argb(82, 77, 219, 177)
    }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.1f
        color = Color.argb(140, 73, 211, 172)
    }
    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2200L
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { phase += 0.018f; invalidate() }
    }

    init { setWillNotDraw(false); setLayerType(LAYER_TYPE_SOFTWARE, null) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!animator.isStarted) animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        val radius = 18f
        fillPaint.shader = LinearGradient(0f, 0f, w, h,
            intArrayOf(Color.argb(155, 5, 31, 34), Color.argb(125, 3, 18, 25), Color.argb(155, 4, 39, 34)),
            null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(0f, 0f, w, h, radius, radius, fillPaint)
        fillPaint.shader = RadialGradient(w * (0.25f + sin(phase).toFloat() * 0.05f), h * 0.2f,
            w * 0.65f, Color.argb(22, 95, 243, 192), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(0f, 0f, w, h, radius, radius, fillPaint)
        fillPaint.shader = null

        canvas.save()
        canvas.clipPath(Path().apply { addRoundRect(0f, 0f, w, h, radius, radius, Path.Direction.CW) })
        ridgePaint.color = Color.argb(62, 76, 216, 175)
        for (index in 0..5) {
            val inset = index * 18f
            val path = Path()
            for (x in 0..width step 18) {
                val y = h * (0.22f + index * 0.13f) + sin(x * 0.015f + phase * (1.2f + index * 0.06f)).toFloat() * (3f + index * 0.3f)
                if (x == 0) path.moveTo(x.toFloat(), y) else path.lineTo(x.toFloat(), y)
            }
            canvas.drawPath(path, ridgePaint)
        }
        canvas.restore()
        canvas.drawRoundRect(0.5f, 0.5f, w - 0.5f, h - 0.5f, radius, radius, edgePaint)
    }
}
