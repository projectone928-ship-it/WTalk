package com.example.wtalk

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

class AudioWaveView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(76, 221, 247)
        strokeWidth = 2.4f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(76, 221, 247)
        strokeWidth = 8f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 185, 244, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
    }

    private var phase = 0f
    private var energy = 0.08f
    @Volatile private var speaking = false

    // This animator never pauses while the view is attached. Voice state only changes energy.
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 720L
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase += 0.105f
            val target = if (speaking) 1f else 0.08f
            energy += (target - energy) * 0.14f
            invalidate()
        }
    }

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isStarted) animator.start()
        else if (!animator.isRunning) animator.resume()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val centerY = height / 2f
        val width = width.toFloat()
        if (width <= 0f || height <= 0) return

        val active = energy > 0.25f
        wavePaint.alpha = if (active) 210 else 70
        canvas.drawLine(12f, centerY, width - 12f, centerY, wavePaint)

        val amplitude = height.coerceAtLeast(20) * (0.08f + 0.34f * energy)
        val step = 7f
        var x = 0f
        var previousY = centerY
        while (x <= width) {
            val normalizedX = x / width
            val envelope = 0.24f + 0.76f * abs(sin(normalizedX * Math.PI)).toFloat()
            val y = centerY + sin(normalizedX * Math.PI * 7.0 + phase).toFloat() * amplitude * envelope
            if (x > 0f) {
                glowPaint.alpha = if (active) 82 else 12
                glowPaint.strokeWidth = if (active) 8f else 4f
                wavePaint.alpha = if (active) 235 else 78
                canvas.drawLine(x - step, previousY, x, y, glowPaint)
                canvas.drawLine(x - step, previousY, x, y, wavePaint)
            }
            previousY = y
            x += step
        }

        bubblePaint.alpha = if (active) 150 else 45
        val bubbleBase = phase * 16f
        for (index in 0..2) {
            val bx = width * (0.22f + index * 0.29f)
            val by = centerY - 16f - ((bubbleBase + index * 19f) % 32f)
            canvas.drawCircle(bx, by, 2f + index * 0.8f, bubblePaint)
        }
    }

    fun startAnimation() {
        speaking = true
        if (!animator.isStarted) animator.start()
        else if (!animator.isRunning) animator.resume()
        invalidate()
    }

    fun stopAnimation() {
        speaking = false
        // Do not pause/cancel: the idle waveform keeps moving and can recover instantly.
        if (!animator.isStarted) animator.start()
        else if (!animator.isRunning) animator.resume()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }
}
