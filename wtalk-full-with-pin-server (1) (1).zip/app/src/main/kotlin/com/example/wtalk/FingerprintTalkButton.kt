package com.example.wtalk

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.util.TypedValue
import android.widget.Button
import kotlin.math.sin

class FingerprintTalkButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.buttonStyle
) : Button(context, attrs, defStyleAttr) {

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL)
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 9f, resources.displayMetrics)
    }
    private val pressedGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val glowRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private var scanPhase = 0f
    @Volatile private var talkPressed = false
    private val scanner = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1250L
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            scanPhase += 0.035f
            invalidate()
        }
    }

    init {
        setWillNotDraw(false)
        background = null
        setTextColor(Color.TRANSPARENT)
        isAllCaps = false
        setPadding(0, 0, 0, 0)
        scanner.start()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = (height * 0.35f).coerceAtLeast(1f)
        val radius = width.coerceAtMost(height).toFloat() * 0.34f
        val pressed = talkPressed || isPressed

        ringPaint.color = if (pressed) Color.rgb(84, 218, 255) else Color.rgb(35, 169, 226)
        ringPaint.alpha = if (pressed) 255 else 220
        ringPaint.strokeWidth = if (pressed) 2.2f else 1.8f
        canvas.drawCircle(cx, cy, radius, ringPaint)

        // A clean empty sensor center, matching the approved concept.
        ringPaint.alpha = if (pressed) 82 else 42
        ringPaint.strokeWidth = 1f
        canvas.drawCircle(cx, cy, radius * 0.72f, ringPaint)

        if (pressed) {
            // Layered under-display light: soft halo, breathing ripple, and white core.
            val breath = ((sin(scanPhase * 1.75f) + 1f) * 0.5f).toFloat()
            val haloRadius = radius * (0.38f + breath * 0.08f)
            pressedGlowPaint.shader = RadialGradient(
                cx, cy, haloRadius,
                intArrayOf(
                    Color.argb(135, 255, 255, 255),
                    Color.argb(58, 190, 244, 255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.38f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, haloRadius, pressedGlowPaint)
            pressedGlowPaint.shader = null

            glowRingPaint.color = Color.WHITE
            glowRingPaint.alpha = (110 + breath * 80f).toInt()
            glowRingPaint.strokeWidth = 1.6f
            canvas.drawCircle(cx, cy, radius * (0.25f + breath * 0.10f), glowRingPaint)

            pressedGlowPaint.color = Color.WHITE
            pressedGlowPaint.alpha = 248
            canvas.drawCircle(cx, cy, radius * (0.105f + breath * 0.018f), pressedGlowPaint)
        }

        if (pressed) {
            ringPaint.color = Color.rgb(120, 235, 255)
            ringPaint.alpha = 235
            ringPaint.strokeWidth = 1.4f
            val scanY = cy - radius * 1.05f + ((scanPhase % 1f) * radius * 2.1f)
            canvas.drawLine(cx - radius * 0.92f, scanY, cx + radius * 0.92f, scanY, ringPaint)
        }

        labelPaint.color = if (pressed) Color.rgb(112, 224, 255) else Color.rgb(90, 186, 222)
        labelPaint.alpha = 235
        canvas.drawText(text.toString().ifBlank { "HOLD TO SPEAK" }, cx, height - 5f, labelPaint)
    }

    fun setTalkPressed(pressed: Boolean) {
        talkPressed = pressed
        refreshDrawableState()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        scanner.cancel()
        super.onDetachedFromWindow()
    }
}
